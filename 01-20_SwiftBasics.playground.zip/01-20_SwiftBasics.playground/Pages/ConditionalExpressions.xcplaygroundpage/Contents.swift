//: Playground - noun: a place where people can play

import UIKit

var myInteger: Int = 10

if myInteger == 5 {
    print("ist gleich 5")
}
else if myInteger == 6 {
    print("ist gleich 6")
}
else if myInteger == 7 {
    print("ist gleich 7")
}
else if myInteger == 8 {
    print("ist gleich 8")
}
else {
    print("ist ungleich 5")
}
