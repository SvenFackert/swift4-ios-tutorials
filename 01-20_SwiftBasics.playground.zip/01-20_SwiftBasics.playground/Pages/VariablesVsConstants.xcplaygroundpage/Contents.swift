//: [Previous](@previous)

import Foundation

let str = "Hello, playground"
let myString: String = "Hello"

// Multi line strings - since swift 4
let multiLineString = """
This is a very long String that covers multiple lines. This is a very long String that covers multiple lines. This is a very long String that covers multiple lines. This is a very long String that covers multiple lines. This is a very long String that covers multiple lines.
"""
